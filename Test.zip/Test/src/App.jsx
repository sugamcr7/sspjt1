import { Route, Routes } from "react-router-dom"
import Login from "./componenets/pages/Login"
import Nav from "./componenets/layouts/Nav"
import Register from "./componenets/pages/Register"
import { Toaster } from "react-hot-toast"
import { Dashboard } from "./componenets/pages/Dashboard"
import CreateProduct from "./componenets/pages/CreateProduct"
import UpdateProduct from "./componenets/pages/UpdateProduct"

function App() {
 

  return (
    <>
     <Nav/>
     <Toaster />

     <Routes>

      <Route path="/" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/createProduct" element={<CreateProduct />} />
      <Route path= "update/:id"
        element={<UpdateProduct/>} />

     </Routes>
    </>
  )
}

export default App
