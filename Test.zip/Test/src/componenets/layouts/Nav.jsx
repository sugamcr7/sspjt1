import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { logout } from "../Redux/slice/authslice";
import toast from "react-hot-toast";
import { baseUrl } from "../services/helper";
import './nav.css'


const Nav = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state?.auth?.user);
  const token = useSelector((state) => state?.auth?.token);
//   console.log(user);
  // console.log(token);

  const logoutHandler = () => {
    dispatch(logout());
    toast.success("Logout");
    navigate("/");
  };

  const navigate = useNavigate();

  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid ">
          <a className="navbar-brand ">
            <div className="d-flex flex wrap gap-2 align-items-center ">
              <img
                src="src\image\STUDENT_LOGO.png"
                alt=""
                height={50}
                width={50}
                className="rounded-circle"
              />
              <h3>Student Server</h3>
            </div>
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0"></ul>
            <div>
              {token ? (
                <div className="d-flex flex wrap gap-3 align-items-center ">
                      <div  className="d-flex flex wrap gap-1">
                    <button
                    className="btn btn-light"
                    onClick={() => navigate("/createProduct")}
                  >
                    Create Product
                  </button>
                    </div>
                  <img
                    src={`${baseUrl}/${user.image}`}
                    alt=""
                    height={60}
                    width={60}
                    className="rounded-circle"
                  />
                  <div>
                    <h5>{user.name}</h5>
                  </div>
                  <div>
                    <button className="btn btn-secondary" onClick={logoutHandler}>
                      Logout
                    </button>
                  </div>
                </div>
              ) : (
                <div className="d-flex flex wrap gap-1">
                  
                
                 <button
                    className="btn btn-dark"
                    onClick={() => navigate("/")}
                  >
                    Login
                  </button>
                  <button
                    className="btn btn-light"
                    onClick={() => navigate("/register")}
                  >
                    Sign Up
                  </button>
              
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Nav;
