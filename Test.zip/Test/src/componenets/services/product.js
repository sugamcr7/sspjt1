import { axiosInstance } from "./helper";


export const getItem=async()=>{
    // console.log(localStorage.getItem('token'));
   try {
    const response=await axiosInstance.get('/product',  {
        headers:
        {'x-access-token':JSON.parse(localStorage.getItem('token'))}
        
      })

   
      console.log(response?.data);
      return response?.data
   } catch (error) {
    console.log(error);
   }
      

}

export const createItem=async(data)=>{
    // console.log(localStorage.getItem('token'));
   try {
    const response=await axiosInstance.post('/create/product',data,  {
        headers:
        {'x-access-token':JSON.parse(localStorage.getItem('token'))}
        
      })

   
      console.log(response?.data);
      return response?.data
   } catch (error) {
    console.log(error);
   }
      

}





export const deleteItem=async(data)=>{
    // console.log(localStorage.getItem('token'));
   try {
    const response=await axiosInstance.delete(`/delete/product/${data}`,  {
        headers:
        {'x-access-token':JSON.parse(localStorage.getItem('token'))}
        
      })

   
    //   console.log(response?.data);
      return response.data
   } catch (error) {
    console.log(error);
   }
      

}

export const updateItem=async(data)=>{
   
   try {
    const response=await axiosInstance.post(`/update/product/${data.id}`,data?.fd , {
        headers:
        {'x-access-token':JSON.parse(localStorage.getItem('token'))}
        
      })

   
    //   console.log(response?.data);
      return response?.data
   } catch (error) {
    console.log(error);
   }
      

}

export const getProductById=async(id)=>{
    // console.log(localStorage.getItem('token'));
   try {
    const response=await axiosInstance.get(`/edit/product/${id}`, {
        headers:
        {'x-access-token':JSON.parse(localStorage.getItem('token'))}
        
      })

   
    //   console.log(response?.data);
      return response?.data
   } catch (error) {
    console.log(error);
   }
      

}