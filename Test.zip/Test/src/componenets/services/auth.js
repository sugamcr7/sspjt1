import toast from "react-hot-toast";
import { axiosInstance } from "./helper";


export const login=async(data)=>{
    try {

        const res= await axiosInstance.post('/login',data)
        console.log(res?.data);
        toast.success(res?.data?.message)
        localStorage.setItem('token',JSON.stringify(res?.data?.token))
        localStorage.setItem('user',JSON.stringify(res?.data?.user))
        return res?.data

        
    } catch (error) {
        console.log(error);
        toast.error(error.message)

    }
}






export const signup=async(data)=>{
    try {

        const res= await axiosInstance.post('/register',data)
        console.log(res?.data);
        // toast.success(res?.data?.message)
        

        
    } catch (error) {
        console.log(error);
    }
}