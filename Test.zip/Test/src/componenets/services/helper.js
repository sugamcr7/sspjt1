import axios from "axios"

export const baseUrl="https://webskitters-student.onrender.com"


export const axiosInstance=axios.create({
    baseURL:baseUrl,

})
