import { createSlice } from '@reduxjs/toolkit'

const initialState = {
 product:null,
 productList:null
}

const productSlice = createSlice({
  name: 'product',
  initialState,
  reducers: {

    getProduct: (state, action) => {
      state.user = action.payload.user
      console.log( action.payload);
    state.token = action.payload.token
    },
    
}})


export const {  } = productSlice.actions

export default productSlice.reducer