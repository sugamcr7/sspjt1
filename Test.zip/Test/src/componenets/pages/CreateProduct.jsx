import { useMutation, useQueryClient } from "@tanstack/react-query";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { createItem } from "../services/product";
import { useNavigate } from "react-router-dom";

const CreateProduct = () => {
  const queryClient = useQueryClient();
    const [image, setImage] = useState(null);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();
  const navigate = useNavigate();

  const { mutate } = useMutation({
    mutationFn: createItem,
    onSuccess: () => {
      console.log("Add successfully");
      //   queryClient.invalidateQueries({ queryKey: ['userList'] })
      queryClient.invalidateQueries(["items"]);
    },
  });
  const submitHandler = async (data) => {
    const fd = new FormData();
    fd.append("name", data?.name);
    fd.append("price", data?.price);
    fd.append("description", data?.description);
    fd.append("brand", data?.brand);

    fd.append("image", image);

    console.log(fd);

    mutate(fd);
    navigate("/dashboard");
  };

  return (
    <div>
      <div className="d-flex align-items-center justify-content-evenly ">
        
        <form className="m-5 p-5" onSubmit={handleSubmit(submitHandler)}>
          <div className="row mb-3">
          <h1>Create Product</h1>
            
            <div className="col-sm-10">
              <input
                type="text"
                className="form-control"
                id="inputEmail3"
                placeholder="Name"
                {...register("name", { required: true })}
              />
            </div>
          </div>
          <div className="row mb-3">
           
            <div className="col-sm-10">
              <input
                type="number"
                className="form-control"
                id="inputEmail4"
                placeholder="Price"
                {...register("price", { required: true })}
              />
            </div>
          </div>
          <div className="row mb-3">
            
            <div className="col-sm-10">
              <input
                type="text"
                className="form-control"
                id="inputEmail5"
                placeholder="Description"
                {...register("description", { required: true })}
              />
            </div>
          </div>
          <div className="row mb-3">
            
            <div className="col-sm-10">
              <input
                type="text"
                className="form-control"
                id="inputEmail6"
                placeholder="Brand"
                {...register("brand", { required: true })}
              />
            </div>
          </div>

          <div className="input-group mb-3">
            
            <input
              type="file"
              className="form-control"
              id="inputGroupFile02"
              onChange={(e) => setImage(e.target.files[0])}
            />
          </div>

          <div className="d-flex flex wrap gap-5">
          <button type="submit" className="btn btn-primary">
            Create Product
          </button>
          </div>
          <div>
          <button onClick={()=>navigate('/dashboard')} className="btn btn-dashboard">
             Go to dashBoard
          </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateProduct;
