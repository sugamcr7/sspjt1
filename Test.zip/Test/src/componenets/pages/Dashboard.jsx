import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React, { useEffect, useState } from "react";
import { deleteItem, getItem } from "../services/product";
import { Link } from "react-router-dom";

export const Dashboard = () => {
  const [search, setSearch]= useState('');

  const queryClient = useQueryClient()
  // const[product,setProduct]=useState([])

  // useEffect(()=>{
  //     setProduct(()=>getItem())
  // },[])

  const { data, error, isLoading, isFetching } = useQuery({
    queryKey: ["items"],
    queryFn: getItem,

  });
  const { mutate } = useMutation({
    mutationFn: deleteItem,
    onSuccess: () => {
      console.log("Delete successfully");
        queryClient.invalidateQueries({ queryKey: ['items'] })
    },
  });

  
  

  
  if(isFetching) return <div>Fetching...</div>
  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;


 
//   console.log(data);
  return (
    <div className="d-flex flex-column align-items-center">
      <div>
        <h1>Products List</h1>
      </div>
      <form className="search">
              <input className="search-input" type="text" placeholder="⌕ Search by Name ...." name="search" onChange={(e)=>setSearch(e.target.value)}/>
            </form>

      <div>
        
        <table className="table table-bordered" width="100%" cellPadding={30} >
        <thead>
          <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Brand</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
        {data?.data?.filter((item)=>{
        return search.toLocaleLowerCase()===''
        ?item
        :item.name.toLocaleLowerCase().includes(search);
      })

          .map((item) => {
            return (
              <tr key={item._id}>
                <td ><img src={item.image} className="card-img-top" alt="..." /></td>
                <td >{item.name}</td>
                <td >{item.description}</td>
                <td >{item.brand}</td>
                <td >{item.price}</td>
                <td ><button className="btn btn-danger" onClick={()=>mutate(item._id)}>Delete It</button></td>
                <td ><Link className='btn btn-primary' to={`/update/${item._id}`}>
                    Update Now
                  </Link></td>
              </tr>
              
              
            );
          })}
          </tbody>
          </table>
        
      </div>
    </div>
  );
};
