import React from "react";
import { useForm } from "react-hook-form";
import { login } from "../services/auth";
import { logIn } from "../Redux/slice/authslice";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";

const Login = () => {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  

  const submithandler = async (data) => {
   
    const res = await login(data);
    console.log(res);
    if (res?.status) {
      dispatch(logIn(res));
      navigate("/dashboard");
    }
   
  };

  return (
    <div className="m-2 d-flex align-items-center justify-content-evenly">
      
      <form onSubmit={handleSubmit(submithandler)}>
        <div className="mb-3">
        <h1> Login</h1>
          
          <input
            type="email"
            className="form-control"
            id="exampleInputEmail1"
            placeholder="Email Address"
            aria-describedby="emailHelp"
            {...register("email", { required: true })}
          />
          
        </div>
        <div className="mb-3">
          
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            placeholder="Password"
            {...register("password", { required: true })}
          />
        </div>
        <div className="mb-3 form-check">
          <input
            type="checkbox"
            className="form-check-input"
            id="exampleCheck1"
          />
          <label className="form-check-label" htmlFor="exampleCheck1">
            Check me out
          </label>
        </div>
        <button type="submit" className="btn btn-primary">
          Login
        </button>
      </form>
    </div>
  );
};

export default Login;
